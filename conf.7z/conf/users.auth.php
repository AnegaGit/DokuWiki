# users.auth.php
# <?php exit()?>
# Don't modify the lines above
#
# Userfile
#
# Format:
#
# login:passwordhash:Real Name:email:groups,comma,separated


baylamon:$1$WY3b2wCn$UbzLtbcDvhJ.vIR61iQxr.:Baylamon:baylamon@web.de:admin,user
